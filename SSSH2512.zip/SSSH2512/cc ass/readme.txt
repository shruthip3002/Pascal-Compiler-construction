Name of group members:
Swetha Krishna Sriram [2020B3A71252H]
P. Sai Shruthi [2020B3A70904H]
Samyak Goel [2020B2A72442H]
Harshil Kankane [2020B4A72230H]


To compile & run the program for task 1 - 

lex sssh2512.l
gcc lex.yy.c -lm
./a.out input.txt

For task 2 - 

yacc -d sssh2512.y
lex sssh2512.l
cc y.tab.c lex.yy.c -lm
./a.out input.txt

The inputs are contained in the file input.txt
